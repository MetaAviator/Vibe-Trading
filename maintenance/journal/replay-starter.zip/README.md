# Verify a synthetic trade report

Use Python 3.12. From this extracted folder, run on macOS or Linux:

    python3.12 -S -m maintenance.journal.examples.synthetic_replay verify maintenance/journal/examples/starter_evidence --expected-id "$(cat maintenance/journal/examples/starter-package-id.txt)"

On Windows PowerShell:

    py -3.12 -S -m maintenance.journal.examples.synthetic_replay verify maintenance/journal/examples/starter_evidence --expected-id (Get-Content maintenance/journal/examples/starter-package-id.txt)

Expect one closed trade, USD 0.50 in fees and USD 4.00 in net P&L. All data is synthetic.
The archive includes the verifier. See the Vibe-Trading Journal Lab to generate new evidence.
