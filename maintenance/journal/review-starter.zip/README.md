# Review a synthetic trade bundle offline

Use Python 3.12 from this extracted folder. On macOS or Linux:

    python3.12 -S -m maintenance.journal.review_bundle verify review.zip --expected-sha256 "$(cat review-sha256.txt)" --verify-fifo --output-html receipt.html

On Windows PowerShell:

    py -3.12 -S -m maintenance.journal.review_bundle verify review.zip --expected-sha256 (Get-Content review-sha256.txt) --verify-fifo --output-html receipt.html

Open receipt.html. Expect USD 0.39 in fees, USD 1.61 in net trade cash and FIFO P&L,
and three matches. For the first match, find executions S001 and S003 in the
trades.csv inside review.zip. The evidence ZIP and all trades are synthetic.
The provided hash identifies this sample. For your own exports, record that hash
separately when creating the bundle and compare it on the receiving machine.
