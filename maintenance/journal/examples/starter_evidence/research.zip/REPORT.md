# Research input bundle

Source schema: Sharadar stocks/SEP; snapshot SHA256: `b84a796c8450ff3855db9d0c14a4b2dfefb93eef9504326dbe25e2afe0fe7e55`.
Selected field: `closeunadj`; basis: `unadjusted`; USD/share; daily EOD.
Requested dates (inclusive): 2026-01-02 to 2026-01-05. Selected rows: 2.
Extraction timestamp recorded: unknown; timezone: unknown.

| Ticker | Observed first date | Observed last date | Rows |
|---|---|---|---:|
| AAA | 2026-01-02 | 2026-01-05 | 2 |

Coverage is observed only. Expected trading-calendar coverage, permanent security identity, and point-in-time availability are not verified.
lastupdated is a revision date. The CSV close column contains the explicitly selected source field; keep metadata.json and request.json with it.
Checksums verify package integrity and file identity, not supplier authenticity, investment results, or account transactions.
Source paths are intentionally omitted. Rebuild with the original local task and the pinned local snapshot.
The ZIP container uses a fixed technical timestamp for reproducible bytes; it is not a data extraction or market timestamp.
